from currency_freaks.handler import get_rate

# __all__ makes get_rate public
__all__ = ['get_rate']